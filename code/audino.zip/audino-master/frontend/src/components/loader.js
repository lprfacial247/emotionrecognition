import React from "react";

const Loader = () => {
  return <div className="spinner-border" role="status"></div>;
};

export default Loader;
