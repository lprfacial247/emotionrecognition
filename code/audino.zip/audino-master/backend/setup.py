from setuptools import setup

setup(name="audino", version="0.1.0", packages=["audino"], include_package_data=True)
