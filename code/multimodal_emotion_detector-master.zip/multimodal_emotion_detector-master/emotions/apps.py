from django.apps import AppConfig


class EmocionesConfig(AppConfig):
    name = 'emotions'
