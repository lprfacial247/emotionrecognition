# Live-Emotion-Recognition-Web-App


A real time Emotion Recognition Web App using CNN to detect seven emotions - angry, disgusted, fearful, happy, neutral, sad and surprised.


Facial Expression serves as a basis for Emotional AI applications like detecting customer emotional responses to Ads and Driver Monitoring Systems.

Technology: Facial Expression Recognition | Image Classification | Tensorflow 2.0 | Convolutional Neural Network(CNNs) | Data Science | Data Visualization | Image Processing | Python | Deep Neural Networks | Artificial Neural Networks | Neural Networks | Deep Learning | Machine Learning | Artificial Intelligence | Flask | Web Application
